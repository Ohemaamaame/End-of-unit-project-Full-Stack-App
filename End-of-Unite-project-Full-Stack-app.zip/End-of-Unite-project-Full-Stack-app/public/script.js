const taskForm = 
  document.getElementById("taskForm");
const taskInput =
  document.getElementById("taskInput");
const taskList =
  document.getElementById("taskList");

const API_URL = "/tasks";

// Fetch tasks from the server
 